#pragma once

class Vector3
{
public:
    int x;
    int y;
    int z;
    Vector3(int x_=NULL,int y_=NULL,int z_=NULL)
    {
        x=x_;
        y=y_;
        z=z_;
    };


protected:

private:
};
