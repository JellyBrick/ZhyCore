# ZhyCore

[![Join the chat at https://gitter.im/ZhyMC/ZhyCore](https://badges.gitter.im/ZhyMC/ZhyCore.svg)](https://gitter.im/ZhyMC/ZhyCore?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

The project is a Server Software on Minecraft Pocket Edition created by C++!

<b>这项工程是一个用 C++ 编写的 Minecraft 便携版的服务端</b>
